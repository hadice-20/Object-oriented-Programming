package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.hr.dao.Donor_Dao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;

public class DeleteDonor extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	
	/**
	 * Create the frame.
	 */
	public DeleteDonor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 598, 356);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 102, 255));
		contentPane.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 0)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter donor id:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel.setBounds(97, 109, 190, 29);
		contentPane.add(lblNewLabel);
		
		final JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Arial", Font.BOLD, 20));
		textArea.setBounds(276, 109, 73, 29);
		contentPane.add(textArea);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String donorIdText = textArea.getText(); 

	                try {
	                    // Call delete method from Donor_Dao class
	                    Donor_Dao.delete(donorIdText);
	                    JOptionPane.showMessageDialog(null, "Donor deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
	                } catch (Exception ex) {
	                    ex.printStackTrace();
	                    JOptionPane.showMessageDialog(null, "Error occurred while deleting donor:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	                }
	            }
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(436, 253, 107, 39);
		contentPane.add(btnNewButton);
	}

}
