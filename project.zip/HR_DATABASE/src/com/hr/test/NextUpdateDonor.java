package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.hr.dao.Donor_Dao;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.UIManager;


public class NextUpdateDonor extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextArea name;
	private JTextArea age;
	private JTextArea gender;
	private JTextArea no;
	private JTextArea type;

	public NextUpdateDonor() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 637, 512);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 191, 255));
		contentPane.setBorder(UIManager.getBorder("Button.border"));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		name = new JTextArea();
		name.setBounds(120, 204, 137, 22);
		contentPane.add(name);
		
		age = new JTextArea();
		age.setBounds(99, 249, 116, 22);
		contentPane.add(age);
		
		gender = new JTextArea();
		gender.setBounds(139, 292, 116, 22);
		contentPane.add(gender);
		
		no = new JTextArea();
		no.setBounds(170, 335, 123, 22);
		contentPane.add(no);
		
		type = new JTextArea();
		type.setBounds(170, 385, 123, 22);
		contentPane.add(type);
		
		
		JLabel lblNewLabel = new JLabel("Enter Donor id:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(52, 141, 155, 32);
		contentPane.add(lblNewLabel);
		
		final JTextArea textArea = new JTextArea();
		textArea.setBounds(193, 148, 56, 22);
		contentPane.add(textArea);
		
		JButton btnNewButton_6 = new JButton("Update");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Donor_Dao.update(textArea.getText(), name.getText(), age.getText(), gender.getText(),no.getText(), type.getText());
					JOptionPane.showMessageDialog(null, "Donor Update successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					e1.printStackTrace();
					JOptionPane.showMessageDialog(null, "Error occurred while Updating Donor:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_6.setBounds(443, 398, 108, 35);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(52, 202, 89, 22);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Age:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(52, 247, 73, 22);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Gender:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(52, 290, 89, 22);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Contact no:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(52, 333, 108, 22);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Blood Type:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_5.setBounds(52, 381, 129, 27);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setBounds(285, 11, 326, 160);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/bbb.jpeg"));
		lblNewLabel_6.setIcon(img);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("UPDATE");
		lblNewLabel_7.setForeground(new Color(0, 0, 0));
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_7.setBounds(81, 11, 116, 42);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("DONOR INFORMATION");
		lblNewLabel_8.setForeground(new Color(0, 0, 0));
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel_8.setBounds(10, 42, 288, 51);
		contentPane.add(lblNewLabel_8);
	
		

			
				
		
		
	}
}
