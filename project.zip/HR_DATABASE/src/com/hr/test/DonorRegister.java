package com.hr.test;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import com.hr.dao.Donor_Dao;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DonorRegister extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Create the frame.
	 */
	public DonorRegister(final JFrame mainFrame) {
		setBackground(new Color(192, 192, 192));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 897, 532);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Back");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnNewButton_3.setBackground(new Color(240, 240, 240));
		btnNewButton_3.setBounds(49, 430, 107, 39);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
				mainFrame.setVisible(true);
		        dispose();
		    }
		});

		final JTextArea textArea_name = new JTextArea();
		textArea_name.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_name.setBounds(118, 134, 170, 23);
		contentPane.add(textArea_name);
		
		final JTextArea textArea_gender = new JTextArea();
		textArea_gender.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_gender.setBounds(132, 181, 129, 23);
		contentPane.add(textArea_gender);
		
		final JTextArea textArea_no = new JTextArea();
		textArea_no.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_no.setBounds(166, 234, 145, 23);
		contentPane.add(textArea_no);
		
		final JTextArea textArea_age = new JTextArea();
		textArea_age.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_age.setForeground(new Color(0, 0, 0));
		textArea_age.setBounds(136, 279, 89, 22);
		contentPane.add(textArea_age);
		
		final JTextArea textArea_blood = new JTextArea();
		textArea_blood.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_blood.setBounds(166, 326, 107, 23);
		contentPane.add(textArea_blood);
		
		JButton btnNewButton_6 = new JButton("Enter");
		btnNewButton_6.setBackground(new Color(240, 240, 240));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Donor_Dao.insert(textArea_name.getText(), textArea_age.getText(), textArea_gender.getText(), textArea_no.getText(), textArea_blood.getText());
					JOptionPane.showMessageDialog(null, "Data entered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception e1) {
                    e1.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error occurred while entering data:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 25));
		btnNewButton_6.setBounds(742, 432, 107, 39);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel.setBounds(39, 134, 99, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Gender:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_1.setBounds(39, 181, 89, 23);
		contentPane.add(lblNewLabel_1);

		
		JLabel lblNewLabel_3 = new JLabel("Contact no:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_3.setBounds(39, 226, 129, 32);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Age:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_4.setBounds(40, 275, 73, 24);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Blood Type:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 21));
		lblNewLabel_5.setBounds(39, 326, 129, 23);
		contentPane.add(lblNewLabel_5);
		ImageIcon img1 = new ImageIcon(this.getClass().getResource("/doctor.jpg"));
		
		JLabel lblNewLabel_6 = new JLabel("ADD DONOR INFORMATION !");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 31));
		lblNewLabel_6.setBounds(216, 22, 471, 39);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(0, 0, 881, 493);
		lblNewLabel_2.setIcon(img1);
		contentPane.add(lblNewLabel_2);
		
	}
}
