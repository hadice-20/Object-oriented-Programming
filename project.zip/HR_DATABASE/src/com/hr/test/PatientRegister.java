package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.hr.dao.Patient_Dao;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JLabel;

public class PatientRegister extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public PatientRegister(final JFrame mainFrame) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 735, 545);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(178, 34, 34));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton button = new JButton("New button");
		button.setBounds(23, 390, 25, -8);
		contentPane.add(button);
		
		JButton btnNewButton_5 = new JButton("Back");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				mainFrame.setVisible(true);
		        dispose();
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBounds(338, 452, 89, 30);
		contentPane.add(btnNewButton_5);
		
		final JTextArea name = new JTextArea();
		name.setFont(new Font("Arial", Font.BOLD, 15));
		name.setBounds(404, 121, 148, 22);
		contentPane.add(name);
		
		final JTextArea age = new JTextArea();
		age.setFont(new Font("Arial", Font.BOLD, 15));
		age.setBounds(404, 169, 89, 22);
		contentPane.add(age);
		
		final JTextArea gender = new JTextArea();
		gender.setFont(new Font("Arial", Font.BOLD, 15));
		gender.setBounds(420, 219, 111, 22);
		contentPane.add(gender);
		
		final JTextArea no = new JTextArea();
		no.setFont(new Font("Arial", Font.BOLD, 15));
		no.setBounds(448, 262, 154, 22);
		contentPane.add(no);
		
		final JTextArea type = new JTextArea();
		type.setFont(new Font("Arial", Font.BOLD, 15));
		type.setBounds(448, 305, 89, 22);
		contentPane.add(type);
		
		JButton btnNewButton_6 = new JButton("Enter");
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					Patient_Dao.insert(name.getText(), age.getText(),gender.getText(),no.getText(),type.getText());
					JOptionPane.showMessageDialog(null, "Data entered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception e1) {
                    e1.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error occurred while entering data:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		btnNewButton_6.setBounds(620, 451, 89, 33);
		contentPane.add(btnNewButton_6);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setForeground(new Color(255, 250, 250));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(338, 116, 77, 33);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Age:");
		lblNewLabel_1.setForeground(new Color(255, 250, 250));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(338, 164, 91, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Gender:");
		lblNewLabel_2.setForeground(new Color(255, 250, 250));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(338, 214, 89, 29);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Contact no:");
		lblNewLabel_3.setForeground(new Color(255, 250, 250));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(338, 254, 121, 34);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Blood Type:");
		lblNewLabel_4.setForeground(new Color(255, 250, 250));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(338, 299, 121, 30);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("");
		ImageIcon img = new ImageIcon(this.getClass().getResource("/789.jpg"));
		lblNewLabel_5.setIcon(img);
		lblNewLabel_5.setBounds(0, 0, 313, 506);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("ADD PATIENT INFORMATION ");
		lblNewLabel_6.setForeground(new Color(0, 0, 0));
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 26));
		lblNewLabel_6.setBounds(323, 11, 396, 51);
		contentPane.add(lblNewLabel_6);
		
		
	}

}
