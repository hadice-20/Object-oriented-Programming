package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.hr.dao.Blood_Dao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;

public class DeleteBlood extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Create the frame.
	 */
	public DeleteBlood() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 592, 410);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 102, 255));
		contentPane.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 0)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Blood id:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(74, 134, 195, 36);
		contentPane.add(lblNewLabel);
		
		final JTextArea id = new JTextArea();
		id.setFont(new Font("Arial", Font.BOLD, 20));
		id.setBounds(264, 134, 95, 36);
		contentPane.add(id);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				        try {
				            // Prompt user for confirmation before deletion (optional)
				            int option = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this record?", "Confirmation", JOptionPane.YES_NO_OPTION);
				            if (option == JOptionPane.YES_OPTION) {
				                // Retrieve blood_id to delete (assuming id is a JTextField where user inputs the blood_id)
				                int bloodIdToDelete = Integer.parseInt(id.getText());

				                // Call DAO method to delete the record
				                Blood_Dao.delete(bloodIdToDelete);

				                // Show success message
				                JOptionPane.showMessageDialog(null, "Blood record deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				            }
				        } catch (NumberFormatException ex) {
				            JOptionPane.showMessageDialog(null, "Error: Please enter a valid blood_id", "Error", JOptionPane.ERROR_MESSAGE);
				        } catch (Exception ex) {
				            ex.printStackTrace();
				            JOptionPane.showMessageDialog(null, "Error occurred while deleting blood record:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				        }
				    }
				});

		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(428, 294, 104, 41);
		contentPane.add(btnNewButton);
	}

}
