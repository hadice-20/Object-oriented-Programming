package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import com.hr.bean.Patient;
import com.hr.dao.Patient_Dao;

import javax.swing.JScrollPane;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.util.ArrayList;

public class ShowPatient extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	/**
	 * Create the frame.
	 */
	 public ShowPatient() {
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setBounds(100, 100, 632, 441);
	        contentPane = new JPanel();
	        contentPane.setBorder(new MatteBorder(9, 9, 9, 9, (Color) new Color(0, 0, 0)));
	        setContentPane(contentPane);
	        contentPane.setLayout(null);

	        scrollPane = new JScrollPane();
	        scrollPane.setBounds(10, 11, 596, 380);
	        contentPane.add(scrollPane);

	        table = new JTable();
	        scrollPane.setViewportView(table);

	        // Call method to populate table with patient data
	        populatePatientTable();
	    }

	    private void populatePatientTable() {
	        try {
	            // Get patient data from DAO method
	            ArrayList<Patient> patientList = Patient_Dao.getAllPatients();

	            // Create table model with column names
	            DefaultTableModel model = new DefaultTableModel();
	            model.addColumn("Patient ID");
	            model.addColumn("Name");
	            model.addColumn("Age");
	            model.addColumn("Gender");
	            model.addColumn("Contact No");
	            model.addColumn("Blood Type");

	            // Populate table model with patient data
	            for (Patient patient : patientList) {
	                Object[] row = {patient.getPatient_id(), patient.getPatient_name(), patient.getPatient_age(),
	                        patient.getPatient_gender(), patient.getPatient_contactno(), patient.getPatient_bloodtype()};
	                model.addRow(row);
	            }

	            // Set the table model to the JTable
	            table.setModel(model);

	            // Adjust column widths
	            TableColumnModel columnModel = table.getColumnModel();
	            columnModel.getColumn(3).setPreferredWidth(99);
	            columnModel.getColumn(4).setPreferredWidth(108);
	            columnModel.getColumn(5).setPreferredWidth(105);

	        } catch (Exception ex) {
	            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	            ex.printStackTrace();
	        }
	    }

}
