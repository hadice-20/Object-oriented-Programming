package com.hr.test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Bloodbank {

	private JFrame frame;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bloodbank window = new Bloodbank();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Bloodbank() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(128, 0, 0));
		frame.getContentPane().setFont(new Font("Algerian", Font.BOLD, 13));
		frame.setBounds(200, 100, 835, 580);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		ImageIcon img = new ImageIcon(this.getClass().getResource("/1809.jpg"));
		lblNewLabel.setIcon(img);
		lblNewLabel.setBounds(0, 0, 819, 447);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setForeground(new Color(128, 0, 0));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		btnNewButton.setBackground(new Color(255, 182, 193));
		btnNewButton.setBounds(162, 471, 160, 59);
		
		btnNewButton.addActionListener((ActionListener) new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		      
		    	Login loginFrame = new Login(frame);
				loginFrame.setVisible(true);
				frame.setVisible(false);
		    }
		});
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Register");
		btnNewButton_1.setForeground(new Color(128, 0, 0));
		btnNewButton_1.setBackground(new Color(255, 182, 193));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 25));
		btnNewButton_1.setBounds(485, 471, 160, 59);
		btnNewButton_1.addActionListener((ActionListener) new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		      
		    	Register registerFrame = new Register(frame);
                registerFrame.setVisible(true);
                frame.setVisible(false);
		    }
		});
		frame.getContentPane().add(btnNewButton_1);	
	
	}    
}

