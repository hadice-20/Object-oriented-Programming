package com.hr.test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import com.hr.bean.Blood;
import com.hr.util.DBUtil;

public class ShowBlood extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public ShowBlood() {
		
		
		 setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	        setBounds(100, 100, 600, 400);
	        contentPane = new JPanel();
	        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	        setContentPane(contentPane);
	        contentPane.setLayout(null);

	        JScrollPane scrollPane = new JScrollPane();
	        scrollPane.setBounds(10, 10, 564, 341);
	        contentPane.add(scrollPane);

	        JTable table = new JTable();
	        scrollPane.setViewportView(table);

	        // Fetch data from the database and populate the table
	        try {
	            ArrayList<Blood> bloodList = getAllBlood();
	            DefaultTableModel model = (DefaultTableModel) table.getModel();
	            model.setColumnIdentifiers(new String[]{"Blood ID", "Blood Type", "Quantity", "Cost", "Expiry Date"});

	            for (Blood blood : bloodList) {
	                Object[] row = {blood.getBlood_id(), blood.getBlood_type(), blood.getBlood_quantity(),
	                        blood.getBlood_cost(), blood.getBlood_exp_date()};
	                model.addRow(row);
	            }
	        } catch (Exception ex) {
	            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
	        }
	    }
		
	
public ArrayList<Blood> getAllBlood() throws Exception {
    ArrayList<Blood> bloodList = new ArrayList<>();
    String sql = "SELECT * FROM BLOOD";

    try (Connection conn = DBUtil.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(sql);
         ResultSet rs = pstmt.executeQuery()) {

        while (rs.next()) {
            Blood blood = new Blood();
            blood.setBlood_id(rs.getInt("BLOOD_ID"));
            blood.setBlood_type(rs.getString("BLOOD_TYPE"));
            blood.setBlood_quantity(rs.getString("BLOOD_QUANTITY"));
            blood.setBlood_cost(rs.getString("BLOOD_COST"));
            blood.setBlood_exp_date(rs.getDate("BLOOD_EXP_DATE"));

            bloodList.add(blood);
        }
    } catch (SQLException ex) {
        throw new Exception("Error retrieving blood data: " + ex.getMessage());
    }

    return bloodList;
}


}
