package com.hr.test;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Enter extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public Enter(final JFrame mainFrame) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 804, 506);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(51, 102, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(237, 97, 541, 339);
		contentPane.add(lblNewLabel);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/360.jpg"));
		lblNewLabel.setIcon(img);
		
		JButton btnNewButton_3 = new JButton("Back");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_3.setBackground(new Color(240, 240, 240));
		btnNewButton_3.setBounds(10, 423, 101, 33);
		contentPane.add(btnNewButton_3);
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        mainFrame.setVisible(true);
		        dispose();
		    }
		});
		
		JButton deletedonor = new JButton("Delete");
		deletedonor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteDonor frame = new DeleteDonor();
				frame.setVisible(true);
			}
		});
		deletedonor.setFont(new Font("Tahoma", Font.BOLD, 15));
		deletedonor.setBounds(10, 65, 89, 31);
		contentPane.add(deletedonor);
		
		JButton showdonor = new JButton("Show");
		showdonor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowDonor frame = new ShowDonor();
				frame.setVisible(true);
			}
		});
		showdonor.setFont(new Font("Tahoma", Font.BOLD, 15));
		showdonor.setBounds(128, 65, 89, 31);
		
		contentPane.add(showdonor);
		
		JButton deletepatient = new JButton("Delete");
		deletepatient.setFont(new Font("Tahoma", Font.BOLD, 15));
		deletepatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeletePatient frame = new DeletePatient();
				frame.setVisible(true);
			}
		});
		deletepatient.setBounds(10, 174, 89, 31);
		contentPane.add(deletepatient);
		
		JButton showpatient = new JButton("Show");
		showpatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowPatient frame = new ShowPatient();
				frame.setVisible(true);
			}
		});
		showpatient.setFont(new Font("Tahoma", Font.BOLD, 15));
		showpatient.setBounds(128, 174, 89, 31);
		contentPane.add(showpatient);
		
		JButton deleteblood = new JButton("Delete");
		deleteblood.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteBlood frame = new DeleteBlood();
				frame.setVisible(true);
			}
		});
		deleteblood.setFont(new Font("Tahoma", Font.BOLD, 15));
		deleteblood.setBounds(10, 343, 89, 31);
		contentPane.add(deleteblood);
		
		JButton showblood = new JButton("Show");
		showblood.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ShowBlood frame = new ShowBlood();
				frame.setVisible(true);
			}
		});
		showblood.setFont(new Font("Tahoma", Font.BOLD, 15));
		showblood.setBounds(128, 343, 89, 31);
		contentPane.add(showblood);
		
		JLabel lblNewLabel_1 = new JLabel("Donor Information");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(10, 21, 207, 31);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Blood Information");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 232, 207, 31);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Patient Information");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(10, 120, 207, 31);
		contentPane.add(lblNewLabel_3);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddBlood frame = new AddBlood();
				frame.setVisible(true);
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(10, 285, 89, 31);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				UpdateBlood frame = new UpdateBlood();
				frame.setVisible(true);
			}
			
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(128, 283, 89, 31);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel_4 = new JLabel("Blood Bank Management System");
		lblNewLabel_4.setForeground(new Color(255, 255, 255));
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		lblNewLabel_4.setBounds(325, 41, 351, 45);
		contentPane.add(lblNewLabel_4);
	}
}
