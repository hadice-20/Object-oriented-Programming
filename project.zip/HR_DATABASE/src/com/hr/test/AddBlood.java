package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hr.dao.Blood_Dao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextArea;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class AddBlood extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public AddBlood() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 595, 453);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Blood Type:");
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(34, 53, 110, 34);
		contentPane.add(lblNewLabel);
		
		final JTextArea type = new JTextArea();
		type.setBounds(154, 61, 128, 22);
		contentPane.add(type);
		
		JLabel lblNewLabel_1 = new JLabel("Blood Cost:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(34, 107, 110, 28);
		contentPane.add(lblNewLabel_1);
		
		final JTextArea cost = new JTextArea();
		cost.setBounds(154, 112, 128, 22);
		contentPane.add(cost);
		
		JLabel lblNewLabel_2 = new JLabel("Blood Quantity:");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(34, 164, 140, 28);
		contentPane.add(lblNewLabel_2);
		
		final JTextArea quantity = new JTextArea();
		quantity.setBounds(184, 169, 128, 22);
		contentPane.add(quantity);
		
		JLabel lblNewLabel_3 = new JLabel("Blood Exp Date:");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBackground(new Color(240, 240, 240));
		lblNewLabel_3.setBounds(34, 222, 153, 28);
		contentPane.add(lblNewLabel_3);
		
		final JTextArea exp = new JTextArea();
		exp.setBounds(184, 227, 128, 22);
		contentPane.add(exp);
		
		
		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            // Retrieve text field values
		            String bloodType = type.getText();
		            String bloodCost = cost.getText();
		            String bloodQuantity = quantity.getText();
		            String expDateString = exp.getText();
		            
		            // Convert date string to java.util.Date
		            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd"); // Example format, adjust as per your input
		            Date expDate = dateFormat.parse(expDateString);
		            
		            // Convert java.util.Date to java.sql.Date
		            java.sql.Date sqlExpDate = new java.sql.Date(expDate.getTime());
		            
		            // Call DAO method with java.sql.Date
		            Blood_Dao.insert(bloodType, bloodCost, bloodQuantity, sqlExpDate);
		            
		            // Show success message
		            JOptionPane.showMessageDialog(null, "Data entered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
		        } catch (ParseException | NumberFormatException e1) {
		            e1.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error: Invalid date format or other input:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		        } catch (Exception e1) {
		            e1.printStackTrace();
		            JOptionPane.showMessageDialog(null, "Error occurred while entering data:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		        }
		    }
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(443, 339, 89, 34);
		contentPane.add(btnNewButton);
		
		
		JLabel lblYyyymmdd = new JLabel("YYYY-MM-DD");
		lblYyyymmdd.setForeground(new Color(255, 255, 255));
		lblYyyymmdd.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblYyyymmdd.setBounds(184, 246, 128, 34);
		contentPane.add(lblYyyymmdd);
		
		JLabel lblNewLabel_4 = new JLabel("");
		ImageIcon img = new ImageIcon(this.getClass().getResource("/212.jpg"));
		lblNewLabel_4.setIcon(img);
		lblNewLabel_4.setBounds(-11, 0, 590, 414);
		contentPane.add(lblNewLabel_4);
	}
}
