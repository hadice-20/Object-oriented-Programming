package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;

import com.hr.dao.Patient_Dao;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;

public class DeletePatient extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	/**
	 * Create the frame.
	 */
	public DeletePatient() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 416);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(204, 102, 255));
		contentPane.setBorder(new MatteBorder(10, 10, 10, 10, (Color) new Color(0, 0, 0)));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Enter Patient id:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(64, 138, 209, 31);
		contentPane.add(lblNewLabel);
		
		final JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Arial", Font.BOLD, 20));
		textArea.setBounds(283, 138, 79, 31);
		contentPane.add(textArea);
		
		JButton btnNewButton = new JButton("Delete");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
						 String PatientIdText = textArea.getText(); 

			                try {
			                    // Call delete method from Donor_Dao class
			                    Patient_Dao.delete(PatientIdText);
			                    JOptionPane.showMessageDialog(null, "Patient deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
			                } catch (Exception ex) {
			                    ex.printStackTrace();
			                    JOptionPane.showMessageDialog(null, "Error occurred while deleting donor:\n" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			                }
			            }
					
				
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(376, 301, 106, 37);
		contentPane.add(btnNewButton);
	}

}
