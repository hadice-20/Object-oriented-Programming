package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.hr.dao.Blood_Dao;

import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.event.ActionEvent;

public class UpdateBlood extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public UpdateBlood() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 584, 465);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(128, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("Blood ID:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(30, 66, 103, 28);
		contentPane.add(lblNewLabel_4);
		
		final JTextArea id = new JTextArea();
		id.setBounds(131, 71, 51, 22);
		contentPane.add(id);
		
		
		
		JLabel lblNewLabel = new JLabel("Blood type:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(32, 115, 101, 28);
		contentPane.add(lblNewLabel);
		
		final JTextArea type = new JTextArea();
		type.setBounds(143, 120, 101, 22);
		contentPane.add(type);
		
		JLabel lblNewLabel_1 = new JLabel("Blood Cost:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(32, 170, 101, 28);
		contentPane.add(lblNewLabel_1);
		
		final JTextArea cost = new JTextArea();
		cost.setBounds(143, 175, 101, 22);
		contentPane.add(cost);
		
		JLabel lblNewLabel_2 = new JLabel("Blood Quantity:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(32, 216, 140, 28);
		contentPane.add(lblNewLabel_2);
		
		final JTextArea quantity = new JTextArea();
		quantity.setBounds(182, 221, 115, 22);
		contentPane.add(quantity);
		
		JLabel lblNewLabel_3 = new JLabel("Blood Exp Date:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(32, 267, 150, 28);
		contentPane.add(lblNewLabel_3);
		
		final JTextArea exp = new JTextArea();
		exp.setBounds(182, 272, 115, 22);
		contentPane.add(exp);
		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				        try {
				            // Retrieve text field values
				            int bloodId = Integer.parseInt(id.getText()); // Assuming id is the ID of the blood record to update
				            String bloodType = type.getText();
				            String bloodCost = cost.getText();
				            String bloodQuantity = quantity.getText();
				            String expDateString = exp.getText();
				            
				            // Convert date string to java.util.Date
				            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				            Date expDate = dateFormat.parse(expDateString);
				            
				            // Convert java.util.Date to java.sql.Date
				            java.sql.Date sqlExpDate = new java.sql.Date(expDate.getTime());
				            
				            // Call DAO method to update the record
				            Blood_Dao.update(bloodId, bloodType, bloodCost, bloodQuantity, sqlExpDate);
				            
				            // Show success message
				            JOptionPane.showMessageDialog(null, "Data updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				        } catch (ParseException | NumberFormatException e1) {
				            e1.printStackTrace();
				            JOptionPane.showMessageDialog(null, "Error: Invalid date format or other input:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				        } catch (Exception e1) {
				            e1.printStackTrace();
				            JOptionPane.showMessageDialog(null, "Error occurred while updating data:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				        }
				    }
				});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setBounds(449, 363, 89, 37);
		contentPane.add(btnNewButton);
		
		
	}
}
