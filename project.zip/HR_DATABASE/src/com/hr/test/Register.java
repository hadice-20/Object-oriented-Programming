package com.hr.test;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.border.LineBorder;

public class Register extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public Register(final JFrame mainFrame) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 692, 508);
		contentPane = new JPanel();
		contentPane.setForeground(SystemColor.inactiveCaptionBorder);
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new LineBorder(new Color(0, 191, 255), 6));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_2 = new JButton("Back");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBackground(new Color(255, 255, 0));
		btnNewButton_2.setBounds(61, 372, 101, 33);
		contentPane.add(btnNewButton_2);
		btnNewButton_2.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        mainFrame.setVisible(true);
		        dispose();
		    }
		});
		
		JButton adddonor = new JButton("Add");
		adddonor.setFont(new Font("Tahoma", Font.BOLD, 18));
		adddonor.setForeground(new Color(0, 0, 0));
		adddonor.setBackground(new Color(240, 240, 240));
		adddonor.setBounds(239, 155, 89, 33);
		adddonor.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	DonorRegister frame = new DonorRegister(mainFrame);
				frame.setVisible(true);
		    }
		});
		contentPane.add(adddonor);
		
		JButton updatedonor = new JButton("Update");
		updatedonor.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NextUpdateDonor frame = new NextUpdateDonor();
				frame.setVisible(true);
			}
		});
		updatedonor.setFont(new Font("Tahoma", Font.BOLD, 18));
		updatedonor.setBounds(377, 155, 101, 33);
		contentPane.add(updatedonor);
		
		JButton addpatient = new JButton("Add");
		addpatient.setFont(new Font("Tahoma", Font.BOLD, 18));
		addpatient.setBounds(239, 256, 89, 33);
		addpatient.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	PatientRegister frame = new PatientRegister(mainFrame);
				frame.setVisible(true);
		    }
		});
		contentPane.add(addpatient);
		
		JButton updatepatient = new JButton("Update");
		updatepatient.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				NextUpdatePatient frame = new NextUpdatePatient();
				frame.setVisible(true);
			}
		});
		updatepatient.setFont(new Font("Tahoma", Font.BOLD, 18));
		updatepatient.setBounds(377, 256, 101, 33);
		contentPane.add(updatepatient);
		
		JLabel lblNewLabel = new JLabel("Register As:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 40));
		lblNewLabel.setForeground(new Color(245, 255, 250));
		lblNewLabel.setBounds(176, 40, 258, 54);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Donor");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_1.setForeground(SystemColor.desktop);
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(101, 143, 101, 46);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Patient");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel_2.setForeground(SystemColor.desktop);
		lblNewLabel_2.setBounds(101, 244, 115, 46);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setBounds(34, 24, 632, 417);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/waves.jpg"));
		lblNewLabel_3.setIcon(img);
		contentPane.add(lblNewLabel_3);
		
		
	}
}
