package com.hr.test;

import javax.swing.JFrame;
import javax.swing.JPanel;


import com.hr.dao.Patient_Dao;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextArea;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.border.LineBorder;

public class NextUpdatePatient extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Create the frame.
	 */
	public NextUpdatePatient() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 634, 495);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(138, 43, 226));
		contentPane.setBorder(new LineBorder(new Color(255, 250, 250), 12));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		

		JLabel lblNewLabel = new JLabel("Enter Patient id:");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(126, 132, 164, 29);
		contentPane.add(lblNewLabel);
		
		final JTextArea textArea_5 = new JTextArea();
		textArea_5.setFont(new Font("Arial", Font.BOLD, 15));
		textArea_5.setBounds(278, 137, 56, 22);
		contentPane.add(textArea_5);
		
		final JTextArea name = new JTextArea();
		name.setFont(new Font("Arial", Font.BOLD, 15));
		name.setBounds(158, 202, 159, 24);
		contentPane.add(name);
		
		final JTextArea age = new JTextArea();
		age.setFont(new Font("Arial", Font.BOLD, 15));
		age.setBounds(138, 242, 83, 22);
		contentPane.add(age);
		
		final JTextArea gender = new JTextArea();
		gender.setFont(new Font("Arial", Font.BOLD, 15));
		gender.setBounds(171, 279, 119, 22);
		contentPane.add(gender);
		
		final JTextArea no = new JTextArea();
		no.setFont(new Font("Arial", Font.BOLD, 15));
		no.setBounds(196, 319, 151, 22);
		contentPane.add(no);
		
		final JTextArea type = new JTextArea();
		type.setFont(new Font("Arial", Font.BOLD, 15));
		type.setBounds(196, 369, 111, 22);
		contentPane.add(type);

		
		JButton btnNewButton_5 = new JButton("Update");
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD | Font.ITALIC, 20));
		btnNewButton_5.setBounds(471, 398, 119, 33);
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					Patient_Dao.update(textArea_5.getText(), name.getText(), age.getText(), gender.getText(),no.getText(), type.getText());
					 JOptionPane.showMessageDialog(null, "Patient Update successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					e1.printStackTrace();
                    JOptionPane.showMessageDialog(null, "Error occurred while Updating Patient:\n" + e1.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		contentPane.add(btnNewButton_5);
		
		JLabel lblNewLabel_1 = new JLabel("Name:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(83, 202, 75, 29);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Age:");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(83, 237, 56, 29);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Gender:");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(83, 275, 89, 27);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Contact No:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_4.setBounds(83, 312, 131, 32);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Blood Type:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_5.setBounds(83, 367, 119, 23);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("");
		ImageIcon img = new ImageIcon(this.getClass().getResource("/ooo.jpeg"));
		lblNewLabel_6.setIcon(img);
		lblNewLabel_6.setBounds(406, 21, 185, 255);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("UPDATE");
		lblNewLabel_7.setForeground(new Color(0, 0, 0));
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_7.setBounds(144, 21, 119, 39);
		contentPane.add(lblNewLabel_7);
		
		JLabel lblNewLabel_8 = new JLabel("PATIENT INFORMATION");
		lblNewLabel_8.setForeground(new Color(0, 0, 0));
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel_8.setBounds(59, 56, 326, 53);
		contentPane.add(lblNewLabel_8);
		
		
	}
}
