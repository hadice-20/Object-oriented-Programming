package com.hr.test;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPasswordField passwordField;
	/**
	 * Create the frame.
	 */
	public Login(final JFrame mainFrame) {
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 504);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton_3 = new JButton("Back");
		btnNewButton_3.setBackground(new Color(248, 248, 255));
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 19));
		btnNewButton_3.setBounds(34, 415, 96, 35);
		contentPane.add(btnNewButton_3);
		
		btnNewButton_3.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        mainFrame.setVisible(true);
		        dispose();
		    }
		});
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(10, 11, 662, 288);
		ImageIcon img = new ImageIcon(this.getClass().getResource("/image.jpg"));
		lblNewLabel.setIcon(img);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Enter");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBackground(new Color(248, 248, 255));
		btnNewButton.setBounds(543, 415, 96, 35);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("Username:");
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_1.setBounds(170, 327, 108, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Password:");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_2.setBounds(170, 364, 100, 21);
		contentPane.add(lblNewLabel_2);
		
		final JTextArea textArea = new JTextArea();
		textArea.setFont(new Font("Arial Black", Font.BOLD, 14));
		textArea.setBounds(280, 328, 144, 22);
		contentPane.add(textArea);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(280, 367, 144, 20);
		contentPane.add(passwordField);
		
		 btnNewButton.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	                String username = textArea.getText();
	                String password = new String(passwordField.getPassword());

	                if (username.equals("hr") && password.equals("hrpass")) {
	                    // Open new frame
	                	Enter frame = new Enter(mainFrame);
						frame.setVisible(true);
	                } else {
	                    // Display error message
	                	if (!username.equals("hr")) {
	                	    JOptionPane.showMessageDialog(contentPane, "Invalid username", "Error", JOptionPane.ERROR_MESSAGE);
	                	} else if (!password.equals("hrpass")) {
	                	    JOptionPane.showMessageDialog(contentPane, "Invalid password", "Error", JOptionPane.ERROR_MESSAGE);
	                	}
	                }
	            }
	        });
	}
}
