package com.hr.dao;

import java.sql.Connection;
import java.sql.Date; // Import java.sql.Date for SQL date
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.hr.bean.Blood;
import com.hr.util.DBUtil;

public class Blood_Dao {
    public static void insert(String blood_type, String blood_cost, String blood_quantity, Date blood_exp_date) throws Exception {
        String sql = "INSERT INTO BLOOD (BLOOD_ID, blood_type, blood_quantity, blood_cost, blood_exp_date) VALUES (BLOOD_SEQ.nextval, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = DBUtil.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, blood_type);
            pstmt.setString(2, blood_quantity);
            pstmt.setString(3, blood_cost);
            pstmt.setDate(4, blood_exp_date);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new blood entry was inserted successfully!");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            DBUtil.getConnection(); // Close connection after usage
        }
    }
    
    public static void update(int blood_id, String blood_type, String blood_cost, String blood_quantity, Date blood_exp_date) throws Exception {
        String sql = "UPDATE BLOOD SET blood_type = ?, blood_quantity = ?, blood_cost = ?, blood_exp_date = ? WHERE BLOOD_ID = ?";

        try (PreparedStatement pstmt = DBUtil.getConnection().prepareStatement(sql)) {
            pstmt.setString(1, blood_type);
            pstmt.setString(2, blood_quantity);
            pstmt.setString(3, blood_cost);
            pstmt.setDate(4, blood_exp_date);
            pstmt.setInt(5, blood_id);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Blood record with ID " + blood_id + " was updated successfully!");
            } else {
                System.out.println("No blood record found with ID " + blood_id);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            DBUtil.getConnection(); // Close connection after usage
        }
    }

    
    public static void delete(int bloodId) throws Exception {
        String sql = "DELETE FROM BLOOD WHERE BLOOD_ID = ?";

        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, bloodId);

            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Blood record with ID " + bloodId + " was deleted successfully!");
            } else {
                System.out.println("No blood record found with ID " + bloodId);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new Exception("Error deleting blood record: " + ex.getMessage());
        }
    }
    
    public static ArrayList<Blood> getAllBlood() throws Exception {
        ArrayList<Blood> bloodList = new ArrayList<>();
        String sql = "SELECT * FROM BLOOD";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Blood blood = new Blood();
                blood.setBlood_id(rs.getInt("BLOOD_ID"));
                blood.setBlood_type(rs.getString("BLOOD_TYPE"));
                blood.setBlood_quantity(rs.getString("BLOOD_QUANTITY"));
                blood.setBlood_cost(rs.getString("BLOOD_COST"));
                blood.setBlood_exp_date(rs.getDate("BLOOD_EXP_DATE"));
                
                bloodList.add(blood);
            }
        } catch (SQLException ex) {
            throw new Exception("Error retrieving blood data: " + ex.getMessage());
        }
        
        return bloodList;
    }
}
