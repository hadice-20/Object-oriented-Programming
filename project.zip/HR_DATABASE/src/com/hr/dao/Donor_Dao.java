package com.hr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.hr.bean.Donor;
import com.hr.util.DBUtil;

public class Donor_Dao {
    public static void insert(String DONOR_NAME, String DONOR_AGE, String DONOR_GENDER, String DONOR_CONTACTNO, String DONOR_BLOODTYPE) throws Exception {
        String sql = "INSERT INTO DONOR (DONOR_ID, DONOR_NAME, DONOR_AGE, DONOR_GENDER, DONOR_CONTACTNO, DONOR_BLOODTYPE) VALUES (DONOR_SEQ.nextval, '" + DONOR_NAME + "', " + DONOR_AGE + ", '" + DONOR_GENDER + "', " + DONOR_CONTACTNO + ", '" + DONOR_BLOODTYPE + "')";
        DBUtil.executeQuery(sql);
        System.out.println("Inserted successfully.");
        DBUtil.conn.close();
    }
    
    public static void delete(String donor_id) throws Exception {
    	String sql = "DELETE  FROM donor WHERE donor_id =" +donor_id;
    	DBUtil.executeQuery(sql);
    	System.out.println("Deleted successfully");
    	DBUtil.conn.close();
    }
    
    public static void update(String donor_id, String DONOR_NAME, String DONOR_AGE, String DONOR_GENDER, String DONOR_CONTACTNO, String DONOR_BLOODTYPE) throws Exception {
        String sql = "UPDATE DONOR SET DONOR_NAME = '" + DONOR_NAME + "', DONOR_AGE = " + DONOR_AGE + ", DONOR_GENDER = '" + DONOR_GENDER + "', DONOR_CONTACTNO = " + DONOR_CONTACTNO + ", DONOR_BLOODTYPE = '" + DONOR_BLOODTYPE + "' WHERE DONOR_ID = " + donor_id;
        DBUtil.executeQuery(sql);
        System.out.println("Updated successfully.");
        DBUtil.conn.close();
    }
    
    public static ArrayList<Donor> getAllDonors() throws Exception {
        ArrayList<Donor> donorList = new ArrayList<>();
        String sql = "SELECT * FROM DONOR";
        
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                Donor donor = new Donor();
                donor.setDonor_id(rs.getInt("DONOR_ID"));
                donor.setDonor_name(rs.getString("DONOR_NAME"));
                donor.setDonor_age(rs.getString("DONOR_AGE"));
                donor.setDonor_gender(rs.getString("DONOR_GENDER"));
                donor.setDonor_contactno(rs.getString("DONOR_CONTACTNO"));
                donor.setDonor_bloodtype(rs.getString("DONOR_BLOODTYPE"));
                
                donorList.add(donor);
            }
        } catch (SQLException ex) {
            throw new Exception("Error retrieving donor data: " + ex.getMessage());
        }
        
        return donorList;
    }

}

