package com.hr.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.hr.bean.Patient;
import com.hr.util.DBUtil;

public class Patient_Dao {
	 public static void insert(String PATIENT_NAME, String PATIENT_AGE, String PATIENT_GENDER, String PATIENT_CONTACTNO, String PATIENT_BLOODTYPE) throws Exception {
	        String sql = "INSERT INTO PATIENT (PATIENT_ID, PATIENT_NAME, PATIENT_AGE, PATIENT_GENDER, PATIENT_CONTACTNO, PATIENT_BLOODTYPE) VALUES (PATIENT_SEQ.nextval, '" + PATIENT_NAME + "', " + PATIENT_AGE + ", '" + PATIENT_GENDER + "', " + PATIENT_CONTACTNO + ", '" + PATIENT_BLOODTYPE + "')";
	        DBUtil.executeQuery(sql);
	        System.out.println("Inserted successfully.");
	        DBUtil.conn.close();
	    }
	 
	 public static void delete(String patient_id) throws Exception {
	    	String sql = "DELETE  FROM patient WHERE patient_id =" +patient_id;
	    	DBUtil.executeQuery(sql);
	    	System.out.println("Deleted successfully");
	    	DBUtil.conn.close();
	    }
	 
	 public static void update(String Patient_id, String PATIENT_NAME, String PATIENT_AGE, String PATIENT_GENDER, String PATIENT_CONTACTNO, String PATIENT_BLOODTYPE) throws Exception {
	        String sql = "UPDATE PATIENT SET PATIENT_NAME = '" + PATIENT_NAME + "', PATIENT_AGE = " + PATIENT_AGE + ", PATIENT_GENDER = '" + PATIENT_GENDER + "', PATIENT_CONTACTNO = " + PATIENT_CONTACTNO + ", PATIENT_BLOODTYPE = '" + PATIENT_BLOODTYPE + "' WHERE PATIENT_ID = " + Patient_id;
	        DBUtil.executeQuery(sql);
	        System.out.println("Updated successfully.");
	        DBUtil.conn.close();
	    }
	 
	 public static ArrayList<Patient> getAllPatients() throws Exception {
	        ArrayList<Patient> patientList = new ArrayList<>();
	        String sql = "SELECT * FROM PATIENT";

	        try (Connection conn = DBUtil.getConnection();
	             PreparedStatement pstmt = conn.prepareStatement(sql);
	             ResultSet rs = pstmt.executeQuery()) {

	            while (rs.next()) {
	                Patient patient = new Patient();
	                patient.setPatient_id(rs.getInt("PATIENT_ID"));
	                patient.setPatient_name(rs.getString("PATIENT_NAME"));
	                patient.setPatient_age(rs.getString("PATIENT_AGE"));
	                patient.setPatient_gender(rs.getString("PATIENT_GENDER"));
	                patient.setPatient_contactno(rs.getString("PATIENT_CONTACTNO"));
	                patient.setPatient_bloodtype(rs.getString("PATIENT_BLOODTYPE"));

	                patientList.add(patient);
	            }
	        } catch (SQLException ex) {
	            throw new Exception("Error retrieving patient data: " + ex.getMessage());
	        }

	        return patientList;
	    }
}
