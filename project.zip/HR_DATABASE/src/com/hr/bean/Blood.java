package com.hr.bean;

import java.util.Date;

public class Blood {
      private int blood_id;
      private String blood_type;
      private String blood_cost;
      private String blood_quantity;
      private Date blood_exp_date;
      
	public int getBlood_id() {
		return blood_id;
	}
	public void setBlood_id(int blood_id) {
		this.blood_id = blood_id;
	}
	public String getBlood_type() {
		return blood_type;
	}
	public void setBlood_type(String blood_type) {
		this.blood_type = blood_type;
	}
	public String getBlood_cost() {
		return blood_cost;
	}
	public void setBlood_cost(String blood_cost) {
		this.blood_cost = blood_cost;
	}
	public String getBlood_quantity() {
		return blood_quantity;
	}
	public void setBlood_quantity(String blood_quantity) {
		this.blood_quantity = blood_quantity;
	}
	public Date getBlood_exp_date() {
		return blood_exp_date;
	}
	public void setBlood_exp_date(Date blood_exp_date) {
		this.blood_exp_date = blood_exp_date;
	}
      
      
}
