package com.hr.bean;

public class Donor {
    private int donor_id;
    private String donor_name;
    private String donor_age;
    private String donor_gender;
    private String donor_contactno;
    private String donor_bloodtype;
	public int getDonor_id() {
		return donor_id;
	}
	public void setDonor_id(int donor_id) {
		this.donor_id = donor_id;
	}
	public String getDonor_name() {
		return donor_name;
	}
	public void setDonor_name(String donor_name) {
		this.donor_name = donor_name;
	}
	public String getDonor_age() {
		return donor_age;
	}
	public void setDonor_age(String donor_age) {
		this.donor_age = donor_age;
	}
	public String getDonor_gender() {
		return donor_gender;
	}
	public void setDonor_gender(String donor_gender) {
		this.donor_gender = donor_gender;
	}
	public String getDonor_contactno() {
		return donor_contactno;
	}
	public void setDonor_contactno(String donor_contactno) {
		this.donor_contactno = donor_contactno;
	}
	public String getDonor_bloodtype() {
		return donor_bloodtype;
	}
	public void setDonor_bloodtype(String donor_bloodtype) {
		this.donor_bloodtype = donor_bloodtype;
	}
    
    
}
